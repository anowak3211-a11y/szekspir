> Superseded on 14 September 2026: see docs/OPERATIONS.md for the v2 pipeline, queue configuration and current prompt contract. Historical notes below may be obsolete.

# SZEKSPIR — system handoff (for an LLM taking over this project)

You are inheriting a working production system. Read this fully before changing anything.

## What this is

SZEKSPIR is a US→UK ad localization pipeline for DTC video ads (current brand: **mellow**, a magnesium bisglycinate sleep/energy supplement sold in the UK). A user pastes a link to a US video ad; the system automatically:

1. downloads the video from the link (server-side),
2. transcribes the audio (OpenAI Whisper, `whisper-1`),
3. rewrites the script into British English via an LLM (offer/retailers/currency/register localized, not just spelling),
4. generates 3 alternative opening hooks + classifies the ad (desire, angle, unique mechanism, funnel stage),
5. writes a complete row into the client's Google Sheet production tracker ("Daily Briefs") with an auto-assigned Ad ID (`MEL-#####`),
6. generates a voiceover mp3 in ElevenLabs (voice picked in the UI dropdown, model `eleven_v3`, script contains emotion tags),
7. sends the video to VMake to remove burned-in captions/subtitles (`videoscreenclear` task),
8. re-hosts the cleaned video and the VO mp3 on Vercel Blob (permanent public URLs),
9. writes `source / VO / clean video` links into the sheet row's "Reference file" column.

The human's entire job is Ctrl+V of a link. Editors work from the sheet.

## Where things run

- **Code**: `~/ad-localizer` on the user's Mac. Next.js 15 (app router, TypeScript) + two Python serverless functions. No git repo as of writing.
- **Production**: https://szekspir.vercel.app — Vercel project `szekspir`, account `anowak3211-3031` (Vercel CLI on the Mac is logged in). Deploy = `cd ~/ad-localizer && vercel deploy --prod --yes`.
- **Access**: HTTP Basic Auth via APP_PASSWORD. Credentials are stored only in environment configuration, not in this handoff.

## Pages

- `/` — hub with tiles: SZEKSPIR, ADVERTORIAL (placeholder), ANTKI (placeholder), PRODUCT.
- `/szekspir` — the tool. Inputs: link textarea (one URL per line; >1 = batch) and file drop (multiple = batch). There is deliberately NO paste-script textarea (user removed it). Controls: engine dropdown (Anthropic / OpenAI / custom OpenAI-compatible), model field, product dropdown, VO-mode checkbox, ElevenLabs voice dropdown (appears with results).
- `/product` — product brief folders. A product = a folder holding multiple `.md` files. Flow is: click a product tile FIRST, then drop `.md` files into it. Tiles show file counts. No text editing on this page (user's explicit requirement) — briefs arrive as ready-made files. All files of the selected product are concatenated and injected into the localization prompt as the authoritative source of truth.
- `/advertorial`, `/antki` — empty "coming soon" placeholders.

## Key source files

- `lib/localize.ts` — THE BRAIN. System prompt with localization rules (vocabulary, retailers CVS→Boots / Walmart→Tesco or Asda, currency, ASA/CAP compliance flagging, ±10% word count for VO timing), hook generation, brief-classification fields, VO-mode rules (flowing paragraphs, numbers as words, ElevenLabs v3 emotion tags like `[warmly]`, 2-6 per script), and rule 9: product brief overrides everything, never invent numbers not in the brief. Also contains the second-pass `critic()` (cheap model: `claude-haiku-4-5-20251001` / `gpt-4o-mini`) that hunts leftover Americanisms only — it must NOT touch offer/numbers/structure/audio tags, and must NOT check claims against the brief (user's explicit decision).
- `lib/fetchad.ts` — resolves a page URL to a direct video URL (regexes over raw HTML: `video_hd_url`, `playable_url`, `og:video`, `<video src>`; direct media links pass through) and downloads it (24MB cap — Whisper's limit is 25MB). Returns `{file, videoUrl}`. FB Ad Library pages are JS-rendered and may fail — then the API returns a clear error telling the user to download manually and drop the file (browser-side audio extraction has no size limit).
- `lib/audio.ts` — client-side: decodes any video/audio in the browser, downmixes to 16kHz mono, encodes ~64kbps mp3 with `@breezystack/lamejs`. This is how big local files bypass Vercel's 4.5MB request body limit.
- `lib/sheets.ts` — `appendToAdminBriefs()` and `updateReference()` (see Sheet section).
- `lib/products.ts` — product folders stored in the OLD sheet's "Products" tab, one row per file: `Product | Filename | Markdown | Updated`.
- `lib/elevenlabs.ts` — `listVoices()` (GET /v1/voices = user's My Voices) and `generateVO(text, voiceId)` (POST text-to-speech, model `eleven_v3`, mp3 44.1kHz 128kbps).
- `app/api/process/route.ts` — POST multipart: `provider`, `model`, `voMode`, `productMd`, and one of `file` | `url` | `text`. Runs fetch→transcribe→localize→critic. Returns `us_script`, `video_url` (resolved direct URL when input was a link), `uk_script`, `hooks[3]`, `hook_og`, `ad_desire`, `ad_angle`, `unique_mechanism`, `funnel`, `notes[]`, `compliance_flags[]`.
- `app/api/export/route.ts` — POST JSON → appends the Daily Briefs row, returns `{adId}`.
- `app/api/vo/route.ts` — POST `{text, voiceId}` returns mp3 stream; with `save:true` uploads to Blob and returns `{url}`.
- `api/vmake_submit.py`, `api/vmake_status.py` — Python serverless functions (see VMake section).
- `app/api/vmake/finalize/route.ts` — downloads VMake's expiring OSS output URL, re-uploads to Blob (`clean/<ts>_<adId>.mp4`), returns permanent URL.
- `app/api/update-reference/route.ts` — writes the reference links into column N by Ad ID.
- `app/szekspir/page.tsx` — UI + client-side orchestration. `postExportPipeline()` runs after a link job's row is exported: auto-VO (currently selected voice) → VMake submit → poll status every 20s (max 20 min) → finalize → update-reference. Per-job live status line. IMPORTANT: this orchestration runs in the browser tab — the tab must stay open until "✅ complete".

## Google Sheets (two spreadsheets — do not confuse them)

Service account: `ad-localizer-bot@ad-localizer-125279921.iam.gserviceaccount.com` (GCP project `ad-localizer-125279921` on the user's **anowak3211@gmail.com** Google account; gcloud CLI on the Mac is logged in as that account). Key file: `google-service-account.json` locally; on Vercel the same JSON is in env `GOOGLE_CREDENTIALS_JSON`.

1. **ADMIN sheet (production tracker, writes go here)**: id `17o5TwwWgdjnkmRZIh8qQloGnhT3otWo8PGEw-nPrKRY`, tab **"Daily Briefs"** (gid 802). Columns A–U: `Ad ID | Ad name | Ad desire | Ad angle | Unique mechanism | Funnel | Landing page | Likes | Adapted script | HOOK OG | Hook 1 | Hook 2 | Hook 3 | Reference file | Your work | Feedback | Approval | Hours spent | Production status | Editor ID | Signed by`. Ad ID = max existing `MEL-(\d+)` + 1, padded to 5 digits. Ad name = `MEL-#####_<FUNNEL>_<slug-of-desire>`. Production status = `To do`. ⚠️ The tab has formatting/validation down to ~row 500, so `values.append` jumps to row 502 — the code writes with `values.update` into the first row after the last filled Ad ID. Keep it that way.
2. **EDITOR sheet**: id `1zi8uoLMsuRTK5cTpBNOiAkKXjEZs1MhNHqbyK5u5zk4` ("mellow — Editor Workspace — TEMPLATE"). It is a template — never write to it.
3. **OLD working sheet**: id `1Qz9efumRtFqQsVPa40l8V9uvpwn5HiK0ALMSMZUfupg` — now used ONLY for the "Products" tab (product brief storage). Its first tab is a leftover, ignore it.

## VMake (caption removal) — hard-won knowledge

VMake's API docs are behind a login. The integration was reverse-engineered from (a) their official Python SDK, whose zip is linked in their dashboard (`https://kapkap-common.stariidata.com/apk/69dceb06854407367i8tj7Iel19574.zip`) and is vendored into the repo at `sdk/`, and (b) the Next.js chunks of vmake.ai/developers.

- Gateway: `https://wapi-skill.vmake.ai`, auth `SDK-HMAC-SHA256` (implemented in `sdk/auth/signer.py`; keys via env `MT_AK` / `MT_SK`).
- Flow: fetch `/skill/config.json` (SkillClient does this on init; also caches a `gid` under `~/.cache` — on Vercel `HOME` is forced to `/tmp`) → upload input to their OSS via `client.api.getFileUrl()` (for http inputs: `client._fetch_http_input_to_tempfile()` first) → `/skill/consume.json` (credits check, returns `context`) → signed POST to the push path with `{params, context, task, task_type, sync_timeout, init_images}` → poll status.
- ⚠️ `init_images` MUST be `[{"url": <oss_url>}]` — a bare string is rejected with a Go unmarshal error.
- `api/vmake_submit.py` forces `sync_timeout: 1` so the job always goes async (returns `{"task_id"}`); `api/vmake_status.py` does exactly ONE status check (`{"done":false}` / `{"done":true,"output_urls":[...]}` / `{"failed":true,...}`) — polling cadence lives in the browser.
- Task for subtitle/caption removal: **`videoscreenclear`**. Other available: `eraser_watermark` (images), `hdvideoallinone`, `image_restoration`. `client.api.getAiStrategy()` etc. come from the vendored SDK; repo root is inserted into `sys.path` so `from sdk...` imports work.
- Output URLs expire (their OSS, `Expires=` param) — ALWAYS re-host via `/api/vmake/finalize` before writing to the sheet.
- Processing a 5s video ≈ 1–2 min; real ads take several minutes. VMake charges the user's credits per job.
- `vercel.json` sets `maxDuration: 300` + 1024MB for `vmake_submit.py` (OSS upload of the video happens inside it). `requirements.txt`: `requests`, `alibabacloud_oss_v2`.

## Env vars (local `.env.local` AND Vercel production)

`ANTHROPIC_API_KEY`, `OPENAI_API_KEY` (Whisper + optional GPT), `ELEVENLABS_API_KEY`, `MT_AK`/`MT_SK` (VMake; `.env.local` also has them as VMAKE_API_KEY/SECRET — the python functions read MT_*), `SPREADSHEET_ID` (= OLD sheet, used by products + legacy), `GOOGLE_CREDENTIALS_JSON` (Vercel only), `APP_PASSWORD`, `BLOB_READ_WRITE_TOKEN` (auto-managed, store `szekspir-files`, public access).

## Known constraints & gotchas

- Vercel request body limit ~4.5MB → link inputs are downloaded server-side (24MB cap, Whisper limit); local file inputs are shrunk client-side to mp3 before upload. Don't "fix" this by posting raw video to a route.
- Whisper rejects files >25MB.
- Google **service accounts cannot create Drive files** (zero storage quota since 2025) — that's why the user creates sheets and shares them with the bot as Editor. Appending/updating shared sheets works fine.
- The critic pass must never alter numbers, offers, product names, `[audio tags]`, or check claims against the brief (user decisions).
- ElevenLabs `eleven_v3` understands inline emotion tags; the VO-mode prompt embeds them. Don't switch to `multilingual_v2` (tags would be read aloud... actually just stripped/ignored — either way keep v3).
- The user communicates in Polish, prefers zero hand-holding, wants maximum automation, and does NOT want a script-paste box or a brief text editor re-added.

## Current state / next planned improvements (not built yet)

1. Golden UK style examples: user will supply winning UK DTC supplement ad scripts → embed as few-shot style exemplars in `lib/localize.ts`.
2. Feedback loop: diff model output vs editor-approved "Adapted script" in Daily Briefs → auto-grow a correction glossary in the prompt.
3. ADVERTORIAL and ANTKI pages are empty placeholders awaiting requirements.
4. Local file inputs skip the VMake/VO/reference part of the pipeline (only link inputs get the full post-export pipeline). Extending it requires client→Blob upload of the original video first.
