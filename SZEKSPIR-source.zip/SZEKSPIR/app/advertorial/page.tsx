export default function Advertorial() {
  return (
    <main className="wrap">
      <p className="crumb">
        <a href="/">← Home</a>
      </p>
      <h1>📰 ADVERTORIAL <span className="tag">US → UK</span></h1>
      <p className="sub">
        Long-form advertorial localization for the UK market — coming soon.
      </p>
      <div className="placeholder">🚧 Under construction</div>
    </main>
  );
}
