export default function Antki() {
  return (
    <main className="wrap">
      <p className="crumb">
        <a href="/">← Home</a>
      </p>
      <h1>🐜 ANTKI <span className="tag">advertorials</span></h1>
      <p className="sub">Coming soon.</p>
      <div className="placeholder">🚧 Under construction</div>
    </main>
  );
}
