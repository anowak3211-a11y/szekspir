import {handleCallback} from '@vercel/queue';
import {syncEditorWorkspace} from '@/lib/editor-sync';
import {scheduleEditorSync} from '@/lib/editor-sync-queue';
export const maxDuration=300;
const callback=handleCallback(async()=>{await syncEditorWorkspace();await scheduleEditorSync(300);});

export async function POST(request:Request){return callback(request);}
