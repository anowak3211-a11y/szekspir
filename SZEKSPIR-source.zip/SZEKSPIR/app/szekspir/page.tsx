'use client';
import {useEffect,useState,useRef,useMemo} from 'react';
import {canCloseFinishedTab,closeFinishedTab} from '@/lib/finish-tab';
import {EDITOR_WORKSPACES} from '@/lib/editor-workspaces';
import VoicePreview from './components/voice-preview';
import FileDrop from './components/file-drop';
import ProductionProgress from './components/production-progress';
import type {UploadStatus} from '@/lib/progress-view';
import {uploadMedia} from '@/lib/media-upload';
import {directedNarration} from '@/lib/voice-direction';
import {diffWords} from 'diff';
import type {Job} from '@/lib/jobs';
import {deliveryVersion} from '@/lib/editor-checklist';
type Voice={preview_url?:string|null;voice_id:string;name:string;labels:Record<string,string>};
function assertUploadActive(id:string){if(localStorage.getItem('szekspir-cancelled-'+id))throw Error('Cancelled by you');}
function uploadStatus(id:string,status:Omit<UploadStatus,'updated'>){try{if(localStorage.getItem('szekspir-cancelled-'+id))return;const key='szekspir-upload-'+id;const previous=JSON.parse(localStorage.getItem(key)||'null');localStorage.setItem(key,JSON.stringify({...status,startedAt:previous?.startedAt||Date.now(),updated:Date.now()}));}catch{}}
function isBritish(v:Voice){return /british|english.?uk|united kingdom|england|london|scottish|welsh|northern irish|received pronunciation/i.test(v.labels?.accent||'');}
type Product={name:string;version?:string};
async function json(url:string,body?:unknown){const r=await fetch(url,{...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{}),cache:'no-store',signal:AbortSignal.timeout(60000)});const j=await r.json();if(!r.ok)throw new Error(j.error||'Request failed');return j;}
export default function Szekspir(){
 const [provider,setProvider]=useState('openai'),[model,setModel]=useState('gpt-5.6-sol');
 const [products,setProducts]=useState<Product[]>([]),[productName,setProductName]=useState('Mellow');
 const [voices,setVoices]=useState<Voice[]>([]),[voiceId,setVoiceId]=useState('');
 const [batchTabs,setBatchTabs]=useState<{id:string;name:string;blocked:boolean}[]>([]);
 const [editorId,setEditorId]=useState('mine');
 const [singingAd,setSingingAd]=useState(false);
 const [voiceoverEnabled,setVoiceoverEnabled]=useState(true),[videoDestination,setVideoDestination]=useState<'vmake'|'drive'|'none'>('drive');
 const [driveReady,setDriveReady]=useState(false),[driveStatus,setDriveStatus]=useState('Checking Google Drive…');
 useEffect(()=>{let active=true;json('/api/drive').then(()=>{if(active){setDriveReady(true);setDriveStatus('Original video · edit scene by scene');}}).catch(()=>{if(active)setDriveStatus('Google account connection required');});return()=>{active=false;};},[]);
 const [inputMode,setInputMode]=useState<'media'|'text'>('media'),[sourceScript,setSourceScript]=useState('');
 const [links,setLinks]=useState(''),[files,setFiles]=useState<File[]>([]),[all,setAll]=useState<Job[]>([]),[selected,setSelected]=useState('');
 const [script,setScript]=useState(''),[hooks,setHooks]=useState<string[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
 const [hookAudio,setHookAudio]=useState<Record<number,string>>({});const [hookBusy,setHookBusy]=useState<Record<number,boolean>>({}),[hookErrors,setHookErrors]=useState<Record<number,string>>({}),[hookSlow,setHookSlow]=useState<Record<number,boolean>>({});
 const submitLock=useRef(false);
 const [uploadBatches,setUploadBatches]=useState(0);
 const uploadTabs=useRef(new Map<string,Window>());
 useEffect(()=>{const channel=new BroadcastChannel('szekspir-finished-tabs');channel.onmessage=event=>{if(event.data?.type==='finished'&&typeof event.data.id==='string'){const tab=uploadTabs.current.get(event.data.id);if(tab){tab.close();uploadTabs.current.delete(event.data.id);}}};return()=>channel.close();},[]);
 const [sendingVo,setSendingVo]=useState(false);
 const [finishResult,setFinishResult]=useState<{ok:boolean;checks:{label:string;ok:boolean;detail?:string}[];editor:string;url:string}|null>(null);
 const [finishing,setFinishing]=useState(false),[finishSlow,setFinishSlow]=useState(false);
 useEffect(()=>{setFinishResult(null);},[script,JSON.stringify(hooks),selected]);
 const [voDuration,setVoDuration]=useState<number>();const loaded=useRef('');
 const [lastChecked,setLastChecked]=useState(0);
 const [cancelling,setCancelling]=useState(false);
 const [pendingUpload,setPendingUpload]=useState<UploadStatus|null>(null);
 useEffect(()=>{if(!selected)return;const read=()=>{try{setPendingUpload(JSON.parse(localStorage.getItem('szekspir-upload-'+selected)||'null'));}catch{}};read();window.addEventListener('storage',read);return()=>window.removeEventListener('storage',read);},[selected]);
 const [editingScript,setEditingScript]=useState(false);
 const [regeneratingScript,setRegeneratingScript]=useState(false),[scriptPreview,setScriptPreview]=useState<string|null>(null);
 const regenerationPending=useRef(false);
 useEffect(()=>{setScriptPreview(null);},[selected]);
 const job=all.find(j=>j.id===selected);
 const [sheetDelivery,setSheetDelivery]=useState<{version:string;checks:{label:string;ok:boolean}[]}|null>(null);
 const [sheetError,setSheetError]=useState('');
 useEffect(()=>{let active=true;let timer:ReturnType<typeof setTimeout>;setSheetDelivery(null);setSheetError('');if(!job?.adId)return;const id=job.id;
 const check=async()=>{try{const result=await json('/api/jobs/delivery?id='+encodeURIComponent(id));if(active){setSheetDelivery(result);setSheetError('');}}catch(e){if(active){setSheetDelivery(null);setSheetError('Could not check the editor sheet: '+(e as Error).message);}}if(active)timer=setTimeout(check,30000);};check();return()=>{active=false;clearTimeout(timer);};},[job?.id,job?.adId]);
 function sheetBadge(label:string,unchanged=true){const ok=!!job&&unchanged&&sheetDelivery?.version===deliveryVersion(job)&&!!sheetDelivery.checks.find(c=>c.label===label)?.ok;return <span className={ok?'sheet-badge confirmed':'sheet-badge'} role="status"><span aria-hidden="true">{ok?'✓':'…'}</span> {ok?'On editor sheet':'Not yet confirmed on sheet'}</span>;}
 const voSent=!!job?.generateVo&&job.voApprovedRevision===(job.revision||0)&&script===job.result?.uk_script&&JSON.stringify(hooks)===JSON.stringify(job.result?.hooks.slice(0,2))&&(!voiceId||voiceId===job.voiceId); 
 const changes=useMemo(()=>diffWords(job?.result?.us_script||'',script),[job?.result?.us_script,script]);
 useEffect(()=>{setSelected(new URLSearchParams(window.location.search).get('job')||'');},[]);
 useEffect(()=>{document.title=job?`${job.adId||job.name} · ${job.status} · SZEKSPIR`:'SZEKSPIR · Localisations';},[job]);
 async function refresh(){const data=await json('/api/jobs'+(new URLSearchParams(window.location.search).get('job')?'?id='+encodeURIComponent(new URLSearchParams(window.location.search).get('job')!):''));setAll(data.jobs||[]);setLastChecked(Date.now());return data.jobs as Job[];}
 useEffect(()=>{json('/api/products').then(j=>setProducts(j.products)).catch(e=>setError(e.message));json('/api/voices').then(j=>setVoices(j.voices||[])).catch(e=>setError(e.message));setVoiceId(localStorage.getItem('szekspir-uk-voice')||'');
  let active=true;
  let timer:ReturnType<typeof setTimeout>;
  const poll=async()=>{if(!active)return;let delay=60000;try{{const jobs=await refresh();if(new URLSearchParams(window.location.search).has('job')||jobs.some(j=>j.status==='Queued'||j.status==='Running'))delay=document.visibilityState==='visible'?10000:30000;}}catch(e){if(active)setError((e as Error).message);}if(active)timer=setTimeout(poll,delay);};
  const wake=()=>{if(document.visibilityState==='visible'){clearTimeout(timer);void poll();}};
  void poll();document.addEventListener('visibilitychange',wake);return()=>{active=false;clearTimeout(timer);document.removeEventListener('visibilitychange',wake);};
 },[]);
 useEffect(()=>{if(job?.result&&loaded.current!==job.id){setScript(job.result.uk_script);setHooks(job.result.hooks.slice(0,2));loaded.current=job.id;setVoDuration(undefined);}},[job]);
 async function submit(){if(submitLock.current)return;submitLock.current=true;setUploadBatches(n=>n+1);setError('');const pending=new Map<string,string>();try{
  if(voiceoverEnabled&&!voiceId)throw new Error('Choose a British voice first');
  if(inputMode==='text'){if(!sourceScript.trim())throw Error('Paste your script first');const id=crypto.randomUUID();const tab=window.open(`/szekspir?job=${id}`,'_blank');if(tab){tab.opener=null;uploadTabs.current.set(id,tab);}setSourceScript('');setTimeout(()=>{submitLock.current=false;},0);await json('/api/jobs',{id,name:sourceScript.trim().slice(0,70),transcript:sourceScript,video:false,voiceoverEnabled,voiceId,provider,model,productName,editorId,singingAd});setMessage('British localisation started.');await refresh();return;}
  const urls=links.split('\n').map(s=>s.trim()).filter(Boolean);
  for(const u of urls)if(!/^https?:\/\//i.test(u))throw new Error('Use complete http/https links');
  const ids=Array.from({length:files.length+urls.length},()=>crypto.randomUUID());
  ids.forEach((id,i)=>{const name=i<files.length?files[i].name:urls[i-files.length];pending.set(id,name);uploadStatus(id,{name,stage:'Queued for upload'});});
  const opened=ids.map(id=>{const tab=window.open(`/szekspir?job=${encodeURIComponent(id)}`,'_blank');if(tab){tab.opener=null;uploadTabs.current.set(id,tab);}return tab;});
  setBatchTabs(old=>[...old,...ids.map((id,i)=>({id,name:i<files.length?files[i].name:urls[i-files.length],blocked:!opened[i]}))]);
  setFiles([]);setLinks('');setTimeout(()=>{submitLock.current=false;},0);
  if(videoDestination==='drive'&&(files.some(f=>f.type.startsWith('video/'))||urls.some(u=>! /\.(mp3|m4a|wav)(\?|$)/i.test(u))))await json('/api/drive');
  const {runUploads}=await import('@/lib/parallel-upload');
  const create=async(input:Record<string,unknown>)=>{const id=String(input.id),name=String(input.name);assertUploadActive(id);uploadStatus(id,{name,stage:'Saving localisation'});let startedAt:number|undefined;try{startedAt=JSON.parse(localStorage.getItem('szekspir-upload-'+id)||'null')?.startedAt;}catch{}await json('/api/jobs',{...input,singingAd,editorId,videoDestination,startedAt,provider,model,productName,voiceId,voiceoverEnabled});pending.delete(id);uploadStatus(id,{name,stage:'Upload complete · loading localisation'});};
  if(files.length&&videoDestination!=='none'){const config=await json('/api/upload');const oversized=files.find(f=>f.size>config.maximumSizeInBytes);if(oversized)throw Error(`${oversized.name} exceeds the ${Math.round(config.maximumSizeInBytes/1024/1024)} MB limit. Choose a smaller file.`);}
  const tasks=files.map((f,index)=>async()=>{const id=ids[index];try{assertUploadActive(id);setMessage(`Preparing audio for ${f.name}…`);uploadStatus(id,{name:f.name,stage:'Preparing audio'});
   const {extractAudioAsMp3}=await import('@/lib/audio');let sourceDuration:number|undefined;const audio=await extractAudioAsMp3(f,seconds=>{sourceDuration=seconds;});
   assertUploadActive(id);if(audio.size>24*1024*1024)throw new Error('Extracted audio is too long; split the recording');
   const ext=(f.name.split('.').pop()||'mp4').toLowerCase().replace(/[^a-z0-9]/g,'');
   let sourceUrl='';
   if(videoDestination!=='none'&&f.type.startsWith('video/')){uploadStatus(id,{name:f.name,stage:'Uploading video'});const source=await uploadMedia(`sources/${id}/source.${ext}`,f,percentage=>uploadStatus(id,{name:f.name,stage:`Uploading video · ${Math.round(percentage)}%`}));sourceUrl=source.url;}
   assertUploadActive(id);uploadStatus(id,{name:f.name,stage:'Uploading audio'});
   const sound=await uploadMedia(`sources/${id}/audio.mp3`,audio,percentage=>uploadStatus(id,{name:f.name,stage:`Uploading audio · ${Math.round(percentage)}%`}));
   await create({id,name:f.name,sourceUrl:sourceUrl||sound.url,audioUrl:sound.url,video:videoDestination!=='none'&&f.type.startsWith('video/'),duration:sourceDuration});
  }catch(e){pending.delete(id);uploadStatus(id,{name:f.name,stage:'Upload not completed',error:(e as Error).message});throw Error(f.name+': '+(e as Error).message);}});
  tasks.push(...urls.map((url,index)=>async()=>{const id=ids[files.length+index];try{await create({id,name:url,sourceUrl:url,video:videoDestination!=='none'&&! /\.(mp3|m4a|wav)(\?|$)/i.test(url)});}catch(e){pending.delete(id);uploadStatus(id,{name:url,stage:'Upload not completed',error:(e as Error).message});throw e;}}));
  const failures=await runUploads(tasks,2);
  if(failures.length){setError(failures.join('\n'));setMessage('Other uploads finished. Failed files are marked in their own tabs.');await refresh();return;}
  setMessage(opened.some(tab=>!tab)?'Jobs saved. Your browser blocked some tabs. Open each localisation from Saved jobs below.':'Jobs saved. Each localisation has its own tab.');await refresh();
 }catch(e){const message=(e as Error).message;setError(message);pending.forEach((name,id)=>uploadStatus(id,{name,stage:'Upload not completed',error:message}));await refresh().catch(()=>{});}finally{submitLock.current=false;setUploadBatches(n=>n-1);}}
 async function save(){if(!job)return;setFinishing(true);setBusy(true);setFinishResult(null);setError('');setFinishSlow(false);const timer=setTimeout(()=>setFinishSlow(true),15000);try{const response=await fetch('/api/jobs/finish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:job.id,script,hooks}),signal:AbortSignal.timeout(240000)});const result=await response.json();if(!response.ok)throw Error(result.error||'Could not verify the editor sheet.');setFinishResult(result);setSheetDelivery(result);if(canCloseFinishedTab(result)){setMessage('Everything is on the editor sheet. Closing this tab…');closeFinishedTab(job.id);}else await refresh();}catch(e){setError((e as Error).message);}finally{clearTimeout(timer);setFinishing(false);setFinishSlow(false);setBusy(false);}}

 async function regenerateScript(){if(!job||regenerationPending.current)return;regenerationPending.current=true;setRegeneratingScript(true);setError('');setScriptPreview(null);try{const response=await fetch('/api/jobs/regenerate-script',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:job.id}),signal:AbortSignal.timeout(290000)});const result=await response.json();if(!response.ok)throw Error(result.error||'Could not regenerate the script');setScriptPreview(result.script);}catch(e){setError((e as Error).message);}finally{regenerationPending.current=false;setRegeneratingScript(false);}}
 async function retry(j:Job){if(j.uncertain&&!confirm('The provider may already have charged for the interrupted request. Check its task history first. Retry this step?'))return;try{await json('/api/jobs',{action:'retry',id:j.id,confirmUncertain:!!j.uncertain});await refresh();}catch(e){setError((e as Error).message);}}
 async function abort(){if(!selected||cancelling)return;setCancelling(true);setError('');try{await json('/api/jobs',{action:'cancel',id:selected});localStorage.setItem('szekspir-cancelled-'+selected,'1');localStorage.removeItem('szekspir-upload-'+selected);setPendingUpload(null);setScriptPreview(null);window.location.replace('/szekspir');}catch(e){setError((e as Error).message);}finally{setCancelling(false);}}

 async function getVoiceover(regenerate=false){if(!job||sendingVo)return;setFinishResult(null);setSendingVo(true);setBusy(true);setError('');try{await json('/api/jobs',{action:regenerate?'regenerate-voiceover':'voiceover',revision:job.revision||0,id:job.id,script,hooks,voiceId:voiceId||job.voiceId});setMessage(regenerate?'✓ Regeneration queued. A new voiceover and two hooks will be recorded.':'✓ Sent to ElevenLabs. Your script and hooks are queued for recording.');await refresh();}catch(e){setError((e as Error).message);}finally{setSendingVo(false);setBusy(false);}}
 async function recordHook(i:number){if(hookBusy[i])return;setFinishResult(null);setHookBusy(old=>({...old,[i]:true}));setHookErrors(old=>({...old,[i]:''}));setHookSlow(old=>({...old,[i]:false}));const timer=setTimeout(()=>setHookSlow(old=>({...old,[i]:true})),15000);try{const r=await fetch('/api/vo',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:hooks[i],voiceId:voiceId||job?.voiceId,jobId:job?.id,hookIndex:i,save:true})});if(!r.ok)throw new Error((await r.json()).error);const data=await r.json();setHookAudio(old=>({...old,[i]:data.url}));await refresh();}catch(e){setHookErrors(old=>({...old,[i]:(e as Error).message}));}finally{clearTimeout(timer);setHookBusy(old=>({...old,[i]:false}));setHookSlow(old=>({...old,[i]:false}));}}

 function download(){const url=URL.createObjectURL(new Blob([script],{type:'text/plain'}));const a=document.createElement('a');a.href=url;a.download='uk-script.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 return <main className="wrap"><p className="crumb"><a href="/">← Home</a></p><h1>🎭 SZEKSPIR <span className="tag">US → UK</span></h1>
 <p className="sub">Keep the argument. Make the English natural. Upload videos or paste links.</p>
 {!selected&&<><div className="controls"><label>Engine<select value={provider} onChange={e=>{setProvider(e.target.value);setModel(e.target.value==='anthropic'?'claude-sonnet-5':e.target.value==='openai'?'gpt-5.6-sol':'');}}><option value="anthropic">Claude</option><option value="openai">OpenAI</option><option value="custom">Custom</option></select></label><label>Model<input list={provider==='openai'?'openai-models':undefined} value={model} onChange={e=>setModel(e.target.value)}/>{provider==='openai'&&<datalist id="openai-models"><option value="gpt-5.6-sol">GPT-5.6 Sol · Recommended for localisation</option><option value="gpt-4o">GPT-4o · Previous model</option></datalist>}</label><label>Product<select value={productName} onChange={e=>setProductName(e.target.value)}><option value="">Source-only localisation</option>{products.map(p=><option key={p.name}>{p.name}</option>)}</select></label></div>
 {inputMode==='media'&&<FileDrop files={files} onChange={setFiles}/>}
 {uploadBatches>0&&<p role="status">Uploading {uploadBatches} batch(es). You can add and start more files now. Keep this page open until uploads finish.</p>}
 <div className="workflow-options">
 <div className="workflow-pair">
 <label className={`workflow-option ${singingAd?'selected':''}`}><input type="checkbox" checked={singingAd} onChange={e=>{setSingingAd(e.target.checked);if(e.target.checked)setVoiceoverEnabled(false);}}/><span><strong>Singing ad</strong><small>Original lyrics · brand replacement only</small></span><span className="option-check" aria-hidden="true">{singingAd?'✓':'+'}</span></label>
 <label className={`workflow-option ${singingAd?'':'selected'}`}><input type="checkbox" checked={!singingAd} onChange={()=>setSingingAd(false)}/><span><strong>British English</strong><small>{singingAd?'Off · original lyrics preserved':'UK script & hooks'}</small></span></label>
 </div>
 <div className="workflow-pair">
 <label className={`workflow-option ${videoDestination==='drive'&&inputMode==='media'?'selected':''} ${inputMode==='text'||!driveReady?'fixed':''}`}><input type="checkbox" checked={videoDestination==='drive'&&inputMode==='media'} disabled={inputMode==='text'||!driveReady} onChange={e=>setVideoDestination(e.target.checked?'drive':'none')}/><span><strong>Send to Drive</strong><small>{inputMode==='text'?'Requires a video':driveStatus}</small></span><span className="option-check" aria-hidden="true">{videoDestination==='drive'&&inputMode==='media'?'✓':'+'}</span></label>
 <label className={`workflow-option ${videoDestination==='vmake'&&inputMode==='media'?'selected':''} ${inputMode==='text'?'fixed':''}`}><input type="checkbox" checked={videoDestination==='vmake'&&inputMode==='media'} disabled={inputMode==='text'} onChange={e=>setVideoDestination(e.target.checked?'vmake':'none')}/><span><strong>Send to VMake</strong><small>{inputMode==='text'?'Requires a video':'Enhance → remove subtitles'}</small></span><span className="option-check" aria-hidden="true">{videoDestination==='vmake'&&inputMode==='media'?'✓':'+'}</span></label>
 </div>
 <label className={`workflow-option voiceover-option ${voiceoverEnabled?'selected':''}`}><input type="checkbox" checked={voiceoverEnabled} onChange={e=>setVoiceoverEnabled(e.target.checked)}/><span><strong>Voiceover</strong><small>ElevenLabs · after script approval</small></span><span className="option-check" aria-hidden="true">{voiceoverEnabled?'✓':'+'}</span></label>
 </div>

 <div className="actions"><button aria-pressed={inputMode==='media'} onClick={()=>setInputMode('media')}>Video / audio</button><button aria-pressed={inputMode==='text'} onClick={()=>setInputMode('text')}>Paste script</button></div>
 {inputMode==='text'?<textarea className="script edit" rows={8} placeholder="Paste the original script. We will localise it into British English." value={sourceScript} onChange={e=>setSourceScript(e.target.value)}/>:
 <div className="inputs"><textarea className="linkbox" placeholder="One ad/video link per line" value={links} onChange={e=>setLinks(e.target.value)}/></div>}
 {voiceoverEnabled&&<div className="vopanel"><label>British voice<select value={voiceId} onChange={e=>{setVoiceId(e.target.value);localStorage.setItem('szekspir-uk-voice',e.target.value);}}><option value="">Choose a voice to start</option>{[...voices].sort((a,b)=>Number(isBritish(b))-Number(isBritish(a))).map(v=><option key={v.voice_id} value={v.voice_id} style={isBritish(v)?{color:'#137440',background:'#eaf8ef',fontWeight:700}:undefined}>{isBritish(v)?'🟢 British · ':''}{v.name}</option>)}</select></label><VoicePreview url={voices.find(v=>v.voice_id===voiceId)?.preview_url}/><p>Review your UK script, then click Send to ElevenLabs to record it.</p></div>}
 <section className="vopanel"><h2>Assign editor</h2><label>Editor <select value={editorId} disabled={busy} onChange={e=>setEditorId(e.target.value)}>{EDITOR_WORKSPACES.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select></label><p>The brief and video link will be sent automatically to this editor’s sheet when ready. Applies to all files in this upload.</p><a href={`https://docs.google.com/spreadsheets/d/${EDITOR_WORKSPACES.find(e=>e.id===editorId)!.sheetId}/edit`} target="_blank" rel="noopener noreferrer">Open editor workspace ↗</a></section>
 <button className="go localise-cta" disabled={busy||(inputMode==='text'?!sourceScript.trim():!files.length&&!links.trim())||(voiceoverEnabled&&!voiceId)} onClick={submit}>{busy?'Starting…':singingAd?'Prepare singing ad →':'Localise to British English →'}</button></>}
 {!selected&&batchTabs.length>0&&<section className="vopanel" aria-label="Processes in this upload"><h2>{batchTabs.length} files · {batchTabs.length} separate processes</h2>{batchTabs.some(t=>t.blocked)&&<p role="alert">Your browser blocked some new tabs. Allow pop-ups for szekspir.vercel.app, or open each process below.</p>}<ul>{batchTabs.map(t=><li key={t.id}><a href={`/szekspir?job=${encodeURIComponent(t.id)}`} target="_blank" rel="noopener noreferrer">{t.name} · {t.blocked?'Open process':'View process'} ↗</a></li>)}</ul><p>Keep this upload page open until all files have been uploaded.</p></section>}
 {error&&<div className="err">{error}</div>}{message&&<p role="status">{message}</p>}
 {selected&&<p><a href="/szekspir">← All localisations / New upload</a></p>}
 {!selected&&<><h2>Saved jobs</h2><div className="batchlist">{all.filter(j=>!j.cancelledAt).map(j=><div className="batchrow" key={j.id}><a href={`/szekspir?job=${encodeURIComponent(j.id)}`} target="_blank" rel="noopener noreferrer">{j.adId ? `${j.adId} · ${j.name.slice(0,55)}` : j.name.slice(0,65)} ↗</a><span>{j.status} · {j.progress||j.step}</span>{j.error&&<span className="batcherr">{j.error}</span>}{j.status==='Failed'&&<button onClick={()=>retry(j)}>Retry this step</button>}</div>)}</div></>}

 {selected&&!job?.cancelledAt&&<ProductionProgress key={`progress-${selected}`} job={job} upload={pendingUpload} lastChecked={lastChecked}/>}
 {selected&&!job?.cancelledAt&&<button className="abort-button" disabled={cancelling} onClick={abort}>{cancelling?'Cancelling…':'Abort and cancel'}</button>}
 {job?.status==='Failed'&&<button onClick={()=>retry(job)}>Retry this step</button>}
 {job?.result&&<><h2>{job.adId||job.name}</h2><p>{job.productName||'Source-only'} · Prompt {job.result.prompt_version} · Product version {job.productVersion||'none'}</p>
 {job.result.language_check&&<p role="status">{script===job.result.uk_script&&JSON.stringify(hooks)===JSON.stringify(job.result.hooks.slice(0,2))?`✓ British English checked · script + 2 hooks · ${job.result.language_check.model}`:"Script edited since the British English check."}</p>}
 <p className="diff-legend"><span className="del">Removed / replaced in US</span> <span className="add">Added / changed in UK</span>{sheetBadge('UK script',script===job.result.uk_script)}{!changes.some(d=>d.added||d.removed)&&' No wording changes.'}</p>
 <div className="cols comparison"><section aria-labelledby="us-heading"><h2 id="us-heading">US original</h2><div className="script">{changes.filter(d=>!d.added).map((d,i)=>d.removed?<del key={i} className="del">{d.value}</del>:<span key={i}>{d.value}</span>)}</div></section><section aria-labelledby="uk-heading"><h2 id="uk-heading">UK script</h2><div className="script">{changes.filter(d=>!d.removed).map((d,i)=>d.added?<ins key={i} className="add">{d.value}</ins>:<span key={i}>{d.value}</span>)}</div></section></div>
 <button className="edit-toggle" aria-expanded={editingScript} aria-controls="uk-editor" onClick={()=>setEditingScript(!editingScript)}>{editingScript?'Close editor':'Edit UK script'}</button>
 <button className="edit-toggle" style={{marginLeft:12}} disabled={regeneratingScript||busy} onClick={regenerateScript}>{regeneratingScript?'Regenerating script…':'↻ Regenerate script'}</button>
 <p>Regenerate from the saved transcript using the latest adaptation rules. Review the draft before applying it.</p>
 {scriptPreview!==null&&<section className="vopanel" aria-label="Regenerated script"><h2>New script draft</h2><div className="script">{scriptPreview}</div><p>Your saved script, hooks and recordings stay unchanged until you apply and save this draft.</p><button onClick={()=>{setScript(scriptPreview);setScriptPreview(null);setEditingScript(true);setMessage('Draft applied locally. Review it, then use Finish to save. Existing recordings have not been regenerated.');}}>Use this script</button><button style={{marginLeft:12}} onClick={()=>setScriptPreview(null)}>Discard draft</button></section>}
 {editingScript&&<div id="uk-editor"><label htmlFor="uk-script-input">Edit UK script · differences update above as you type</label><textarea id="uk-script-input" className="script edit" rows={16} value={script} onChange={e=>setScript(e.target.value)}/></div>}
 <h2>Alternative hooks</h2><p>The original hook is included in the main voiceover. Record only the two alternative openings here.</p>{sheetError&&<p role="alert" className="err">{sheetError}</p>}{hooks.map((h,i)=><div key={i}>{sheetBadge(`Hook ${i+1}`,h===job.result?.hooks[i])}<textarea className="script edit" rows={2} disabled={!!hookBusy[i]} value={h} onChange={e=>setHooks(old=>old.map((x,k)=>i===k?e.target.value:x))}/><button disabled={!!job.abortedAt||!!hookBusy[i]||!!job.hookVoPending?.[i]||!(voiceId||job.voiceId)} className="primary-action" onClick={()=>recordHook(i)}>{hookBusy[i]?'Recording…':'Record hook'}</button>{sheetBadge(`Hook ${i+1} voiceover`,h===job.result?.hooks[i])}{hookSlow[i]&&<p role="status">Still recording and syncing this hook. You can record the other hooks meanwhile.</p>}{hookErrors[i]&&<p role="alert" className="err">{hookErrors[i]}</p>}{(hookAudio[i]||job.hookVoUrls?.[i])&&<div style={{display:'flex',flexWrap:'wrap',gap:16}}>{job.hookVoOriginalUrls?.[i]&&<div><p>Original</p><audio aria-label={`Hook ${i+1} original`} controls src={job.hookVoOriginalUrls[i]}/></div>}<div><p>{job.hookVoTimings?.[i]?`✓ Shortened · ${job.hookVoTimings[i].removedSeconds.toFixed(1)}s removed`:'Voiceover'}</p><audio aria-label={`Hook ${i+1} shortened`} controls src={hookAudio[i]||job.hookVoUrls?.[i]}/></div></div>}</div>)}
 <div className="vopanel"><h2>Approve script & record</h2><details><summary>ElevenLabs script · emotions & delivery</summary><p style={{whiteSpace:"pre-wrap"}}>{directedNarration(script)}</p></details><p>Send to ElevenLabs approves the script and all two hooks shown above. ElevenLabs will only run after you click.</p><label>British voice<select value={voiceId||job.voiceId} onChange={e=>{setVoiceId(e.target.value);localStorage.setItem('szekspir-uk-voice',e.target.value);}}><option value="">Choose a voice</option>{[...voices].sort((a,b)=>Number(isBritish(b))-Number(isBritish(a))).map(v=><option key={v.voice_id} value={v.voice_id} style={isBritish(v)?{color:'#137440',background:'#eaf8ef',fontWeight:700}:undefined}>{isBritish(v)?'🟢 British · ':''}{v.name}</option>)}</select></label><VoicePreview url={voices.find(v=>v.voice_id===(voiceId||job.voiceId))?.preview_url}/><button disabled={!!job.abortedAt||busy||(voSent&&!job.stages?.vo?.error)||!(voiceId||job.voiceId)||!!(job.generateVo&&job.voApprovedRevision===(job.revision||0)&&job.stages?.vo?.started&&!job.stages.vo.done)} className="primary-action" onClick={()=>getVoiceover()}>{sendingVo?'Sending…':voSent?(job.stages?.vo?.error?'Voiceover error · check status':'✓ Sent to ElevenLabs'):'Send to ElevenLabs'}</button>{job.voUrl&&(!job.stages?.vo||job.stages.vo.done)&&<button className="primary-action" disabled={busy||sendingVo||!!job.abortedAt||!(voiceId||job.voiceId)} onClick={()=>getVoiceover(true)} style={{marginLeft:12}}>↻ Regenerate voiceover</button>}{job.previousVo&&<p><a href={job.previousVo.url} target="_blank" rel="noopener noreferrer">Previous voiceover ↗</a></p>}{voSent&&<p role="status">{job.stages?.vo?.error?'Your request was accepted, but recording hit an error. See the progress below.':job.stages?.vo?.done?'✓ Voiceover and hooks are ready.':'✓ Request accepted. Track recording progress below.'}</p>}</div>
 {job.result.data_gaps.length>0&&<details><summary>Product reference notes</summary>{job.result.data_gaps.map((g,i)=><p key={i}>{g.original}<br/>{g.needed}</p>)}</details>}
 <details><summary>Localisation changes</summary>{job.result.notes.map((n,i)=><p key={i}>{n.original} → {n.replacement}<br/>{n.reason}</p>)}</details>
 {job.result.timing&&<p>Spoken word count: {job.result.timing.sourceWords} → {job.result.timing.targetWords}. {job.result.timing.withinTarget?'Within the text-length target.':'Text length differs; check pacing.'}</p>}
 {job.voUrl&&<section><h2>Voiceover comparison</h2>{sheetBadge('Main voiceover',script===job.result.uk_script)}{job.voNeedsRegeneration&&<p role="alert">The script has changed. This is the previous recording — regenerate the voiceover to match the new script.</p>}<div style={{display:'flex',flexWrap:'wrap',gap:16}}>{job.voOriginalUrl&&<div className="vopanel" style={{flex:'1 1 280px'}}><h3>Original · ElevenLabs</h3><audio aria-label="Original voiceover" controls src={job.voOriginalUrl} style={{width:'100%'}}/><a href={job.voOriginalUrl} target="_blank" rel="noreferrer">Download original</a></div>}<div className="vopanel" style={{flex:'1 1 280px',background:'#eefbf3'}}><h3>{job.voTiming?'✓ Shortened automatically':'Voiceover'}</h3><audio aria-label="Shortened voiceover" controls src={job.voUrl} onLoadedMetadata={e=>setVoDuration(e.currentTarget.duration)} style={{width:'100%'}}/><a href={job.voUrl} target="_blank" rel="noreferrer">Download shortened voiceover</a>{job.voTiming&&<p role="status">✓ Pause cleanup complete: {job.voTiming.originalSeconds.toFixed(1)}s → {job.voTiming.trimmedSeconds.toFixed(1)}s. Removed {job.voTiming.removedSeconds.toFixed(1)}s of pauses.</p>}</div></div>{voDuration&&<p>Voiceover: {voDuration.toFixed(1)}s.</p>}</section>}
 {job.driveUrl&&<p><a href={job.driveUrl} target="_blank" rel="noreferrer">Open original video in Drive</a></p>}
 {job.cleanUrl&&<p><a href={job.cleanUrl} target="_blank" rel="noreferrer">Open clean video</a></p>}
 <div className="actions"><button className="primary-action" onClick={save} disabled={busy||!!job.leaseUntil&&job.leaseUntil>Date.now()}>{finishing?'Checking editor sheet…':'Finish'}</button>{finishSlow&&<p role="status">Still synchronising and checking the editor sheet. Please keep this page open.</p>}{finishResult&&<section className="vopanel" aria-label="Editor delivery checklist"><h3>{finishResult.ok?'✓ Complete in editor workspace':'Not finished — check missing items'}</h3><p>{finishResult.editor}</p><ul>{finishResult.checks.map(check=><li key={check.label}>{check.ok?'✓':'✗'} {check.label}{check.detail&&` — ${check.detail}`}</li>)}</ul><a href={finishResult.url} target="_blank" rel="noopener noreferrer">Open editor sheet ↗</a></section>}<button onClick={download}>Download script</button><button onClick={()=>navigator.clipboard.writeText(script)}>Copy script</button></div></>}

 <style jsx>{`
 .controls{justify-content:center}

 .localise-cta{display:block;margin:32px auto 20px;width:min(100%,520px);min-height:72px;padding:20px 28px;border-radius:18px;font-size:clamp(19px,2.3vw,24px);font-weight:750;line-height:1.3;transition:transform .18s,box-shadow .18s}
 .localise-cta:not(:disabled){animation:localise-pulse 2.8s ease-in-out infinite}
 .localise-cta:hover:not(:disabled){animation:none;transform:translateY(-2px);box-shadow:0 8px 24px #16834c35}
 .localise-cta:active:not(:disabled){transform:scale(.98)}
 @keyframes localise-pulse{0%,100%{box-shadow:0 0 0 0 #16834c24;transform:scale(1)}50%{box-shadow:0 0 0 9px #16834c00;transform:scale(1.015)}}
 @media(prefers-reduced-motion:reduce){.localise-cta:not(:disabled){animation:none}.localise-cta{transition:none}.localise-cta:hover:not(:disabled),.localise-cta:active:not(:disabled){transform:none}}
 .workflow-options{display:grid;grid-template-columns:1fr 1fr;gap:18px 28px;margin:24px 0}
 .workflow-pair{display:grid;grid-template-columns:1fr 1fr;gap:12px}
 .voiceover-option{grid-column:1 / -1;justify-self:center;width:min(100%,360px);box-sizing:border-box}
 .workflow-pair .workflow-option{min-width:0;padding:18px 16px}
 .workflow-option{display:flex;align-items:center;gap:12px;padding:20px;border:2px solid #dce3df;border-radius:18px;background:white;cursor:pointer;transition:background .16s,border-color .16s,transform .12s,box-shadow .16s}
 .workflow-option.selected{background:#eaf8ef;border-color:#16844b;box-shadow:0 3px 12px #16844b12}
 .workflow-option:not(.fixed):hover{transform:translateY(-2px);box-shadow:0 5px 16px #183c2320}
 .workflow-option:not(.fixed):active{transform:scale(.98)}
 .workflow-option:focus-within{outline:3px solid #1647c9;outline-offset:3px}
 .workflow-option input{width:20px;height:20px;accent-color:#16844b;flex-shrink:0}
 .workflow-option strong,.workflow-option small{display:block}.workflow-option small{margin-top:6px;color:#4b6253;font-size:13px;line-height:1.4}
 .option-check{margin-left:auto;color:#137440;font-size:22px;font-weight:bold}.fixed{cursor:default}

 .actions button[aria-pressed="true"]{background:#eaf8ef;border-color:#16844b;color:#125f36}
 @media(max-width:1000px){.workflow-options{grid-template-columns:1fr;gap:16px}.voiceover-option{width:min(100%,360px)}}
 @media(max-width:480px){.workflow-pair{gap:8px}.workflow-pair .workflow-option{padding:14px 10px;gap:8px}.workflow-option strong{font-size:14px}.option-check{display:none}}
 @media(prefers-reduced-motion:reduce){.workflow-option{transition:none}.workflow-option:not(.fixed):hover,.workflow-option:not(.fixed):active{transform:none}}
 `}</style>
 </main>;
}
