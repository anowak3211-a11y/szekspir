import {send} from '@vercel/queue';
export async function scheduleEditorSync(delaySeconds=0){
 const slot=delaySeconds?Math.floor(Date.now()/60000)+1:Math.floor(Date.now()/1000);
 await send('szekspir-editor-sync',{kind:'sync'},{region:'iad1',delaySeconds,retentionSeconds:86400,idempotencyKey:`editor-sync-${delaySeconds?'minute':'now'}-${slot}`});
}
