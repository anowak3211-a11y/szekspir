export const EDITOR_WORKSPACES=[
 {id:'mine',name:'Ja (admin)',sheetId:'1zi8uoLMsuRTK5cTpBNOiAkKXjEZs1MhNHqbyK5u5zk4'},
 {id:'editor-2',name:'Maja',sheetId:'1HK8q1zZJLSGSIPrEno0ZsJNTBhWHHaezrHt24EK7kto'},
 {id:'editor-3',name:'Martyna',sheetId:'1D5-fQI1SI0LA2UL1XktEraD8zjmadEuLOGSiRSNQF0M'},
 {id:'editor-4',name:'Kyle Baniqued',sheetId:'1LZoHkbJGrtXqRHjF3rO6t0VT3wm4Qur4RAKgnLtp1c4'},
 {id:'editor-5',name:'Kashieca Nicole Cantila',sheetId:'1ObZ1PER8eqqY4qZBfkI9giMufTt0inHptPEqR-sGMAo'},
 {id:'editor-6',name:'Cedrick Manzanilla',sheetId:'116RyS6EAPj8DY9lXyGadMtX-2JeNk1CyODIkrKxDVnE'},
 {id:'editor-7',name:'Ron',sheetId:'1n5vtQPBy5i23Z4GmdTp-Nm-Q2wHmqb8LOZReg0Mwu9k'},
 {id:'editor-8',name:'Dustin Jerusalem Pielago',sheetId:'1BEbJkqv5Y1e83RxYm0wSicV9pXfLcfxWUjDjkFsgh6c'}
] as const;
