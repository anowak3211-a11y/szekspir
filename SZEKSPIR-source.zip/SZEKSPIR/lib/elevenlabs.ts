import {directedNarration} from './voice-direction';
import type {VoiceTiming} from './vo-cleanup';
import {cleanVoiceover} from './vo-cleanup';
const BASE = "https://api.elevenlabs.io/v1";

function key(): string {
  const k = process.env.ELEVENLABS_API_KEY;
  if (!k) throw new Error("ELEVENLABS_API_KEY not set");
  return k;
}

export interface Voice {
  voice_id: string;
  name: string;
  category: string;
  preview_url?: string | null;
  labels: Record<string, string>;
}

export async function listVoices(): Promise<Voice[]> {
  const r = await fetch(`${BASE}/voices`, {
    headers: { "xi-api-key": key() },
    cache: "no-store",
  });
  if (!r.ok) throw new Error(`ElevenLabs voices: ${r.status} ${await r.text()}`);
  const j = await r.json();
  return (j.voices || []).map((v: Voice) => ({
    voice_id: v.voice_id,
    name: v.name,
    category: v.category,
    preview_url: v.preview_url || null,
    labels: v.labels || {},
  }));
}

export async function generateVO(
  text: string,
  voiceId: string,
  preserve?:(raw:ArrayBuffer,timing:VoiceTiming)=>Promise<void>
): Promise<ArrayBuffer> {
  const r = await fetch(`${BASE}/text-to-speech/${voiceId}?output_format=mp3_44100_128`, {
    method: "POST",
    headers: { "xi-api-key": key(), "Content-Type": "application/json" },
    body: JSON.stringify({
      text:directedNarration(text),
      model_id: "eleven_v3",
    }),
  });
  if (!r.ok) throw new Error(`ElevenLabs TTS: ${r.status} ${await r.text()}`);
  const raw=await r.arrayBuffer();
  try{let timing:VoiceTiming|undefined;const clean=await cleanVoiceover(raw,t=>{timing=t;});if(preserve&&timing)await preserve(raw,timing);return clean;}finally{new Uint8Array(raw).fill(0);}
}
