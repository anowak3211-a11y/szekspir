import {mayIntroduceMellow,hasUnwantedBrandReveal} from './brand-disclosure';
import {narration} from './speech';
import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';
import {SYSTEM_PROMPT,CRITIC_PROMPT,PROMPT_VERSION} from './localization-rules';
import {objectJson,validateResult,applyCritic,timing,opening,LocalizeResult} from './validation';
export type {LocalizeResult} from './validation';
export type Provider='anthropic'|'openai'|'custom';
export async function localize(usScript:string,provider:Provider,model:string,productMd?:string,_voMode?:boolean,singingAd=false,targetBrand="MELLOW"):Promise<LocalizeResult>{
 const lyrics=singingAd?(productMd?.trim()?usScript.replace(/\bp\s*[-–‑]\s*nutrition\b|spenatrician\b|\bS\.?\s*P\.?(?:\s*[-–]?\s*Nutrition)?\b/gi,()=>targetBrand):usScript):undefined;
 const disclosureInstruction=mayIntroduceMellow(usScript)?'Only replace explicitly named source brands at the same point in the script. P-nutrition and Spenatrician are confirmed transcriptions of SP Nutrition, including againSpenatrician; substitute the target brand there and preserve the preceding word.':'HARD RULE: the US source contains no SP/SP Nutrition brand. Do not introduce MELLOW or its full branded product name in script or hooks. Generic magnesium bisglycinate must stay generic. S tier is a ranking, not SP. Preserve ingredient wording and product disclosure.';
 const user=JSON.stringify({disclosureInstruction,mode:productMd?.trim()?'BRAND_ADAPTATION':'FAITHFUL_SOURCE',productContext:productMd||'',sourceTranscript:usScript});
 let raw=await complete(provider,model,SYSTEM_PROMPT,user,120000); let result:LocalizeResult;
 try{result=validateResult(objectJson(raw),2);}catch{
  raw=await complete(provider,model,SYSTEM_PROMPT,user+'\nPrevious output had an invalid schema. Return exactly the requested JSON contract; do not omit fields.',60000);
  result=validateResult(objectJson(raw),2);
 }
 if(hasUnwantedBrandReveal(usScript,[result.uk_script,...result.hooks])){
  const corrected=await complete(provider,model,SYSTEM_PROMPT,user+'\nThe previous attempt introduced a brand absent from the source. Regenerate faithfully with NO MELLOW or added product reveal. Return the full JSON contract.',120000);
  result=validateResult(objectJson(corrected),2);
  if(hasUnwantedBrandReveal(usScript,[result.uk_script,...result.hooks]))throw Error('Adaptation added a brand absent from the US source. No new script was saved. Please regenerate.');
 }
 if(lyrics!==undefined){result.uk_script=lyrics;result.notes=lyrics===usScript?[]:[{original:"Source brand",replacement:targetBrand,reason:"Singing ad: original lyrics preserved; brand replacement only."}];}
 // Check the context-sensitive adaptation without appending a stock CTA.
 const checks=await Promise.all([result.uk_script,...result.hooks].map(async (text,index)=>{
  if(singingAd&&index===0)return {uk_script:text,fixes:[]};
  for(let attempt=0;attempt<2;attempt++){
   try{return await critic(text,provider,model);}catch(error){if(attempt===1)throw new Error('British English check failed. Please retry localisation.');}
  }
  throw new Error('British English check failed.');
 }));
 checks.forEach((checked,i)=>{
  if(i===0){result.uk_script=checked.uk_script;result.notes.push(...checked.fixes);}
  else result.hooks[i-1]=checked.uk_script;
 });
 if(hasUnwantedBrandReveal(usScript,[result.uk_script,...result.hooks]))throw Error('Adaptation added a brand absent from the US source. No new script was saved. Please regenerate.');
 if(!singingAd)result.language_check={model:criticModel(provider),checkedAt:new Date().toISOString()};

 result.narration=singingAd?result.uk_script:narration(result.uk_script);result.hook_og=opening(result.uk_script);result.timing=timing(usScript,result.uk_script);result.prompt_version=PROMPT_VERSION+(singingAd?"-singing":"");
 return result;
}
async function complete(
  provider: Provider,
  model: string,
  system: string,
  user: string,
  timeout = 30000
): Promise<string> {
  if (provider === "anthropic") {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY, timeout, maxRetries: 0 });
    const resp = await client.messages.create({
      model: model || "claude-sonnet-5",
      max_tokens: 8000,
      system,
      messages: [{ role: "user", content: user }],
    });
    return resp.content
      .filter((b) => b.type === "text")
      .map((b) => (b as { text: string }).text)
      .join("");
  }

  // openai or any OpenAI-compatible endpoint (custom baseURL)
  const client = new OpenAI({
    timeout, maxRetries: 0,
    apiKey:
      provider === "custom"
        ? process.env.CUSTOM_API_KEY
        : process.env.OPENAI_API_KEY,
    baseURL: provider === "custom" ? process.env.CUSTOM_BASE_URL : undefined,
  });
  const resp = await client.chat.completions.create({
    model: model || (provider === "openai" ? "gpt-5.6-sol" : "gpt-4o"),
    ...(provider === "openai" && /^(gpt-5\.6(?:-(?:sol|terra|luna))?)(?:$|-)/.test(model || "gpt-5.6-sol") ? { reasoning_effort: "none" as const } : {}),
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  });
  return resp.choices[0].message.content || "";
}


function criticModel(provider:Provider){return provider==='anthropic'?'claude-haiku-4-5-20251001':'gpt-4o-mini';}
export async function critic(script:string,provider:Provider,_model:string){
 const raw=objectJson(await complete(provider==='custom'?'openai':provider,criticModel(provider),CRITIC_PROMPT,JSON.stringify({script})));
 if(!Array.isArray(raw.fixes))throw new Error('Invalid British English check response');
 const fixed=applyCritic(script,raw.fixes);return {uk_script:fixed.script,fixes:fixed.fixes};
}
export async function prepareNarration(script:string,_provider:Provider,_model:string){return narration(script);}
export async function transcribeWithDuration(file:File):Promise<{text:string;duration?:number}>{
 const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY,timeout:60000,maxRetries:0});
 const response=await client.audio.transcriptions.create({file,model:'whisper-1',response_format:'verbose_json'});
 return {text:response.text,duration:response.duration};
}
export async function transcribe(file:File){return (await transcribeWithDuration(file)).text;}
