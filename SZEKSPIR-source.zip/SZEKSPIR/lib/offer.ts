// CTA decisions belong to contextual localisation. Never rewrite approved copy here.
export function applyOffer(script:string,_product:string){return script;}
