// Server-only state transport. No key or payload is returned in error messages.
function config(){
 const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SECRET_KEY||process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key)throw Error('Supabase state storage is not configured');
 const parsed=new URL(url);if(parsed.protocol!=='https:')throw Error('Supabase requires HTTPS');
 return {url:parsed.origin,key};
}
async function rpc(name:string,body:unknown){
 const {url,key}=config();
 const r=await fetch(`${url}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:key,...(key.startsWith('eyJ')?{Authorization:`Bearer ${key}`}:{ }),'Content-Type':'application/json'},body:JSON.stringify(body),cache:'no-store',signal:AbortSignal.timeout(20000)});
 if(!r.ok)throw Error(`Database state request failed (HTTP ${r.status})`);
 return r.json();
}
export async function readDatabaseState(name:string):Promise<{payload:string;version:string}|null>{
 const rows=await rpc('szekspir_state_read',{p_name:name});
 if(!Array.isArray(rows)||rows.length>1)throw Error('Invalid database state response');
 if(!rows.length)return null;
 const row=rows[0];if(typeof row.payload!=='string'||!/^\d+$/.test(row.version))throw Error('Invalid database state record');
 return row;
}
export async function writeDatabaseState(name:string,payload:string,expected?:string){
 if(expected!==undefined&&!/^\d+$/.test(expected))throw Error('Invalid database state version');
 const version=await rpc('szekspir_state_write',{p_name:name,p_payload:payload,p_expected:expected??null});
 if(version===null){const error=Error('Concurrent state update');error.name='BlobPreconditionFailedError';throw error;}
 if(typeof version!=='string'||!/^\d+$/.test(version))throw Error('Invalid database state version');
 return {etag:version};
}
