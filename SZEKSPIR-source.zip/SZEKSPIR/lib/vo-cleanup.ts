import ffmpeg from 'ffmpeg-static';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const run=promisify(execFile);
export const VO_CLEANUP_VERSION='pause-cleanup-v8-500ms-shorter';
// Remove up to 100 ms more from quiet gaps than v7; retain 80 ms minimum.
async function trimPass(input:string,output:string,duration:number,minimum:number,remove:number,retain:number){
 const detected=await run(ffmpeg!,['-hide_banner','-nostdin','-i',input,'-af',`silencedetect=noise=-34dB:d=${minimum}`,'-f','null','-'],{timeout:90000,maxBuffer:8*1024*1024});
 const cuts:Array<[number,number]>=[];let start:number|undefined;
 for(const match of detected.stderr.matchAll(/silence_(start|end): ([\d.]+)/g)){
  if(match[1]==='start'){start=Number(match[2]);continue;}
  const end=Number(match[2]);
  if(start!==undefined&&start>.1&&end<duration-.1&&end-start>=minimum){
   const amount=Math.min(remove,Math.max(0,end-start-retain)),middle=(start+end)/2;
   if(amount>0)cuts.push([middle-amount/2,middle+amount/2]);
  }
  start=undefined;
 }
 const segments:Array<[number,number]>=[];let previous=0;
 for(const [a,b] of cuts){segments.push([previous,a]);previous=b;}
 segments.push([previous,duration]);
 const filters=segments.map(([a,b],i)=>`[0:a]atrim=start=${a}:end=${b},asetpts=PTS-STARTPTS[a${i}]`);
 filters.push(segments.map((_,i)=>`[a${i}]`).join('')+`concat=n=${segments.length}:v=0:a=1[out]`);
 await run(ffmpeg!,['-hide_banner','-loglevel','error','-nostdin','-n','-i',input,'-filter_complex',filters.join(';'),'-map','[out]','-c:a','libmp3lame','-b:a','192k',output],{timeout:90000,maxBuffer:1024*1024});
}
async function audioDuration(input:string){
 const check=await run(ffmpeg!,['-hide_banner','-loglevel','error','-nostdin','-i',input,'-map','0:a:0','-f','null','-','-progress','pipe:1'],{timeout:30000,maxBuffer:1024*1024});
 const times=[...check.stdout.matchAll(/out_time_us=(\d+)/g)].map(m=>Number(m[1]));
 const duration=Math.max(...times)/1e6;
 if(!Number.isFinite(duration)||duration<=0)throw Error('Invalid audio duration');
 return duration;
}
export type VoiceTiming={originalSeconds:number;trimmedSeconds:number;removedSeconds:number;cleanupVersion:string};
export async function cleanVoiceover(raw:ArrayBuffer,onTiming?:(timing:VoiceTiming)=>void):Promise<ArrayBuffer>{
 if(!ffmpeg)throw Error('Voiceover cleanup is unavailable');
 const dir=await mkdtemp(join(tmpdir(),'szekspir-vo-'));
 try{
  const input=join(dir,'raw.audio'),output=join(dir,'clean.mp3');
  await writeFile(input,Buffer.from(raw),{mode:0o600});
  const originalSeconds=await audioDuration(input),intermediate=join(dir,'pass-one.mp3');
  await trimPass(input,intermediate,originalSeconds,.48,.7,.08);
  await trimPass(intermediate,output,await audioDuration(intermediate),.18,.3,.08);
  const trimmedSeconds=await audioDuration(output);
  onTiming?.({originalSeconds,trimmedSeconds,removedSeconds:Math.max(0,originalSeconds-trimmedSeconds),cleanupVersion:VO_CLEANUP_VERSION});
  const clean=await readFile(output);if(clean.length<128)throw Error('Empty cleaned audio');
  return new Uint8Array(clean).buffer;
 }catch{throw Error('Voiceover pause cleanup failed. No unprocessed audio was published.');}
 finally{await rm(dir,{recursive:true,force:true});}
}
