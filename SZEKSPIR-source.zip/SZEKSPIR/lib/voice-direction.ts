import {narration} from './speech';
/** Delivery cues only: keep the spoken words from the approved script. */
export function directedNarration(script:string){
 const text=narration(script);
 const sentences=Array.from(new Intl.Segmenter('en-GB',{granularity:'sentence'}).segment(text),x=>x.segment.trim()).filter(Boolean);
 return sentences.map((sentence,i)=>{
  const tone=/click the link|buy two|free|offer/i.test(sentence)?'excited':i===0||sentence.endsWith('?')?'curious':/sleep|rested|relax|gentle|calm/i.test(sentence)?'reassuring':'confident';
  return `[${tone}] ${sentence}`;
 }).join(' ');
}
