process.env.GOOGLE_APPLICATION_CREDENTIALS='/Users/jakubcabanowski/ad-localizer/google-service-account.json';
const fs=require('fs'),ts=require('typescript'),assert=require('assert');require.extensions['.ts']=(m,f)=>m._compile(ts.transpile(fs.readFileSync(f,'utf8'),{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}),f);
const {google}=require('googleapis'),{sheetAuth}=require('../lib/sheets.ts'),{assignEditor,syncEditorWorkspace}=require('../lib/editor-sync.ts'),{EDITOR_WORKSPACES}=require('../lib/editor-workspaces.ts');
const api=google.sheets({version:'v4',auth:sheetAuth()}),master='17o5TwwWgdjnkmRZIh8qQloGnhT3otWo8PGEw-nPrKRY',id='MEL-00000';let seeded=false;
async function rows(sheet){return (await api.spreadsheets.values.get({spreadsheetId:sheet,range:"'My Tasks'!A1:M501"})).data.values||[];}
(async()=>{try{
const prior=await api.spreadsheets.values.get({spreadsheetId:master,range:"'Daily Briefs'!A502:W502"});if(prior.data.values?.some(r=>r.some(Boolean)))throw Error('Test row occupied');
const r=Array(23).fill('');r[1]=id;r[9]='Temporary assignment verification';r[10]='Hook';r[11]='One';r[12]='Two';r[13]='Three';
await api.spreadsheets.values.update({spreadsheetId:master,range:"'Daily Briefs'!A502:W502",valueInputOption:'RAW',requestBody:{values:[r]}});seeded=true;
await assignEditor(id,'editor-2');for(const w of EDITOR_WORKSPACES){const found=(await rows(w.sheetId)).filter(r=>r[0]===id);assert.equal(found.length,w.id==='editor-2'?1:0);}
const e2=EDITOR_WORKSPACES[1],rr=await rows(e2.sheetId),idx=rr.findIndex(r=>r[0]===id)+1;
await api.spreadsheets.values.update({spreadsheetId:e2.sheetId,range:`'My Tasks'!I${idx}`,valueInputOption:'RAW',requestBody:{values:[['https://example.com/assignment-verification']]}});
await assignEditor(id,'editor-3');const a=await api.spreadsheets.values.get({spreadsheetId:master,range:"'Daily Briefs'!Q502:V502"});assert.equal(a.data.values[0][0],'https://example.com/assignment-verification');assert.equal(a.data.values[0][5],'editor-3');
for(const w of EDITOR_WORKSPACES){const found=(await rows(w.sheetId)).filter(r=>r[0]===id);assert.equal(found.length,w.id==='editor-3'?1:0);}
console.log('PASS LIVE: assignment appears only in selected workspace; Your work returns to master; reassignment preserves submission and removes former copy.');
}finally{if(seeded){await api.spreadsheets.values.clear({spreadsheetId:master,range:"'Daily Briefs'!A502:W502"});await syncEditorWorkspace();for(const w of EDITOR_WORKSPACES)assert(!(await rows(w.sheetId)).some(r=>r[0]===id));console.log('Temporary verification row removed from all sheets.');}}})().catch(e=>{console.error(e.message);process.exitCode=1});
