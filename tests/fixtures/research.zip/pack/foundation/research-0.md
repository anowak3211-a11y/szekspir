# Example 0
Research data.