# Example 1
Research data.