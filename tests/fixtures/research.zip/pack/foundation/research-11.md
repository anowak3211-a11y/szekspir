# Example 11
Research data.