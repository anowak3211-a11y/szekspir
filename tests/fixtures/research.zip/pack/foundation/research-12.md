# Example 12
Research data.