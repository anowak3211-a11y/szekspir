# Example 2
Research data.