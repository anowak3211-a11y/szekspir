# Example 3
Research data.