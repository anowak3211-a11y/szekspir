# Example 4
Research data.