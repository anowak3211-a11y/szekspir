# Example 5
Research data.