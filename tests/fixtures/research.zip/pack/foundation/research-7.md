# Example 7
Research data.