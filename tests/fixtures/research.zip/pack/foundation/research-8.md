# Example 8
Research data.