# Example 9
Research data.